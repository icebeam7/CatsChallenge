﻿using CatsChallenge.Entities;

namespace CatsChallenge.SAL
{
    public class Cats : Cat
    {
        public string Version { get; set; }
    }
}